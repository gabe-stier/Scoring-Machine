# Scoring-Machine
[![deepcode](https://www.deepcode.ai/api/gh/badge?key=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJwbGF0Zm9ybTEiOiJnaCIsIm93bmVyMSI6ImdhYmUtc3RpZXIiLCJyZXBvMSI6IlNjb3JpbmctTWFjaGluZSIsImluY2x1ZGVMaW50IjpmYWxzZSwiYXV0aG9ySWQiOjI2MTA1LCJpYXQiOjE2MDk0NjM1MjJ9.SkSlEk480EPGn9kWZoEVAuGJfRu3iojSMlisdxDhaaw)](https://www.deepcode.ai/app/gh/gabe-stier/Scoring-Machine/_/dashboard?utm_content=gh%2Fgabe-stier%2FScoring-Machine)

This scoring machine was created to help the CCDC team of SEMO prepare with their firewalls.
If any issues arise, you can read the code and attempt to fix the issue yourself or contact Gabe Stier, this machine's code will be hosted on a private repo.
Created by Gabe Stier <gabezter@gmail.com>, if you wish to get in touch email me. I will be more than willing to help fix any issues that could arise or create any new features.
